import mysql.connector

# Configuración de la conexión
config = {
  'user': 'root',
  'password': 'VMau',
  'host': 'localhost',
  'port': '3306',
}

# Conexión con MySQL
try:
    cnx = mysql.connector.connect(**config)
    cursor = cnx.cursor()

    # Crear la base de datos 'itba_casino' si no existe
    cursor.execute("CREATE DATABASE IF NOT EXISTS itba_casino")

    print("Base de datos 'itba_casino' creada exitosamente.")

except mysql.connector.Error as err:
    print(f"Error: {err}")

finally:
    if 'cnx' in locals() and cnx.is_connected():
        cursor.close()
        cnx.close()
