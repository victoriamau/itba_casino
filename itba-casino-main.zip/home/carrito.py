

def add_to_cart(request, chips_to_buy):
    chips_to_buy = int(chips_to_buy)
    if chips_to_buy > 0:
        cart = request.session.get('cart', [])
        cart.append(chips_to_buy)
        request.session['cart'] = cart

def checkout(request):
    cart = request.session.get('cart', [])
    total_chips = sum(cart)
    current_chips = request.session.get('chips', 0)
    request.session['chips'] = current_chips + total_chips
    request.session['cart'] = []
